PC-98 마도전기 1·2·3 한글 패치 1.0.0

대상: 마도물어 1·2·3 합본 재발매판 일본어 FD, sector-linear HDM.
세 편의 System/Sampling 디스크에 각각 적용하는 BPS 6개입니다.
지원 원본의 정확한 파일명, 크기와 SHA-256은 manifest.json에 있습니다.
다른 판본, D88 및 기존 패치 적용본은 입력 대상이 아닙니다.
원본 게임 이미지와 BIOS는 포함하지 않습니다.

적용 방법
1. 원본 디스크와 세이브용 Data disk를 백업합니다.
2. 각 편과 디스크 종류에 맞는 BPS를 대응하는 원본 HDM에 적용합니다.
   저장소의 도구로 검증한 명령:
   pc98_madou apply-bps --source "원본.hdm" --patch "해당패치.bps" --output "한글.hdm"
   도구는 cargo build --locked로 빌드한 target/debug/pc98_madou입니다.
3. 출력 파일의 SHA-256을 manifest.json의 target_sha256과 대조합니다.
4. 같은 편의 한글 System/Sampling 두 장을 함께 사용합니다.
   부팅 시 System을 A:, Sampling을 B:에 넣고 게임의 교체 안내를 따릅니다.
   공용 Data disk는 패치하지 않습니다. 별도로 보관한 쓰기 가능한 사본을 사용합니다.

확인 범위
최신 소스로 세 편을 재조립했고, 설치 파일 재추출 및 BPS 6개 재적용 결과가
목표 디스크와 바이트 단위로 일치합니다. 이전 빌드의 세 편 완주 기록은 있으나
이 ZIP에서 재구성한 디스크의 새 전체 완주는 수행하지 않았습니다.
기존 세이브의 모든 상태에 대한 호환성 전수 검증은 하지 않았습니다.
